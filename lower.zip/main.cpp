/******************************************************************************

Welcome to GDB Online
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<vector>
#include<iostream>
#include <algorithm>
using namespace std;

int main()
{
    int n,x,q,y;
    vector<int>v ;
    cin>>n;
    cout<<"enter elements in sorted manner";
    for(int i=0;i<n;i++)
    {
        cin>>x;
        v.push_back(x);
        
    }
    cout<<"\n";
    cin>>q;
     for(int i=0;i<q;i++)
     {
     cin>>y;
     for(int i=0;i<n;i++)
     {
         if(y==v[i])
         cout<<"Yes"<<" "<<i+1;
         else
         cout<<"No\t"<<v[i+1];
     }
     cout<<"\n";
     }
 
}





